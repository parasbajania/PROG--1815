﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace INCLASS_TASK
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        DataTable table = new DataTable();
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {



        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                StreamWriter saw = new StreamWriter("table.txt", true);

                string a = textBox2.Text;
                string b = textBox3.Text;
                string c = textBox4.Text;
                string d = textBox5.Text;
                string E = textBox6.Text;
                string f = textBox7.Text;
                string g = textBox8.Text;
                saw.WriteLine(a + " /" + b + " /" + c + " /" + d + " /" + E + " /" + f + " /" + g);
                /*saw.WriteLine(b);
                saw.WriteLine(c);
                saw.WriteLine(d);
                saw.WriteLine(E);
                saw.WriteLine(f);
                saw.WriteLine(g);*/
                saw.Close();
                MessageBox.Show("Your data is created ");
            }
            else if (radioButton2.Checked)
            {
                string dead;
                OpenFileDialog rest = new OpenFileDialog();
                rest.InitialDirectory = Directory.GetCurrentDirectory();
                if (rest.ShowDialog() == DialogResult.OK)
                {
                    dead = rest.FileName;
                    label1.Text = "";
                    StreamReader read = new StreamReader(dead);
                    while (read.EndOfStream == false)
                    {
                        label12.Text = label12.Text + "   " + read.ReadLine();

                    }
                    read.Close();
                }

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {


            string delimiter = "/";
            string tablename = "Table";
            DataSet dataset = new DataSet();
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "All Files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {


                string filename = openFileDialog1.FileName;
                StreamReader sr = new StreamReader(filename);
                string csv = File.ReadAllText(openFileDialog1.FileName);
                dataset.Tables.Add(tablename);
                dataset.Tables[tablename].Columns.Add("#");
                dataset.Tables[tablename].Columns.Add("Purchase-Data");
                dataset.Tables[tablename].Columns.Add("Serial #");
                dataset.Tables[tablename].Columns.Add("Manufacturing Tools");
                dataset.Tables[tablename].Columns.Add("Price");
                dataset.Tables[tablename].Columns.Add("Qty");
                dataset.Tables[tablename].Columns.Add("Amount");

                string allData = sr.ReadToEnd();
                string[] rows = allData.Split("\r".ToCharArray());

                foreach (string r in rows)
                {
                    string[] items = r.Split(delimiter.ToCharArray());
                    dataset.Tables[tablename].Rows.Add(items);
                }
                this.dataGridView1.DataSource = dataset.Tables[0].DefaultView;
            }
            else
            {
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string deade;
            OpenFileDialog obj = new OpenFileDialog();
            obj.InitialDirectory = Directory.GetCurrentDirectory();
            if (obj.ShowDialog() == DialogResult.OK)
            {
                deade = obj.FileName;
                label1.Text = "";
                StreamWriter stw = new StreamWriter(deade);
                string deed = textBox2.Text + textBox3.Text + textBox4.Text + textBox5.Text + textBox6.Text + textBox7.Text + textBox8.Text;
                stw.Close();
            }
        }
    }
}
      
    


